
#include "syscall.h"
#include "string.h"

void main(void) {
    _msgout("Hello, world!");
}
